# migration
class RemoveAfterItemFromDeployPlanItem < ActiveRecord::Migration[5.1]
  def change
    # Nothing to see here. Move along!
  end
end
